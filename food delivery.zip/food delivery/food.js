const row2 = document.querySelector(".row2");
const price = document.querySelector(".price");

price.addEventListener("click", () => {
  row2.classList.toggle("show");
});