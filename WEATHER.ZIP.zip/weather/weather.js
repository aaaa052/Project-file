let appid = '47b13ae7d9e258bb56aa6cb4e14e1796';
letunits = 'metric';
let searchMethod;
//q means searching as a string 
function getsearchMethod(searchTerm)
{
    if(searchTerm.length === 5 && Number.parseInt(searchTerm) + "=== searchTerm")
    searchMethod = 'zip';
    else
    searchMethod = 'q';


    function searchweather(searchTerm) 
        getSearchMethod(searchTerm);
        fetch(`https://api.openweathermap.org/data/2.5/weather?zip={zip code},{country code}&appid={API key}`)
            .then((result) => {
                return result.json();
            }).then((res) => {
                init(res);
        });
    
}

function init(resultFromServer)
{
    switch (resultFromServer.weather[0].mian)
    {
        case 'Clear':
            document.body.style.backgroundImage = URL;
            break;

        case 'Clouds':
            document.body.style.backgroundImage = "url('https://upload.wikimedia.org/wikipedia/commons/6/62/Clear_weather_clouds.jpg')";
            break;   

        case 'Rain':
            document.body.style.backgroundImage = "url('')";
            break;

        case 'Mist':
            document.body.style.backgroundImage = "url('')";
            break;

        case 'Thunderstrom':
            document.body.style.backgroundImage = "url('')";
             break;

        case 'Snow':
            document.body.style.backgroundImage = "url('')";
            break;     

        default:
            break;
    }
    
    let weatherDescriptionHeader = document.getElementById('weatherDescriptionHeader');
    let temperatureElement = document.getElementById('temperature');
    let humbidityElement = document.getElementById('humbidity');
    let windSpeedElement = document.getElementById('windSpeed');
    let cityHeader = document.getElementById('cityHeader');


    let weathericon = document.getElementById('documenticonimg');
    weather.src = '' + resultFromServer.weather[0].icon + '.png';

    let resultDescription = resultFromServer.weather[0].description;
    weatherDescriptionHeader.innerText = resultDescription.charAt(0).toUpperCase() + resultDescription.slice(1);
    temperatureElement.innerHTML = Math.floor(resultFromServer.wind.speed) +'&#176';
    windSpeedElement.innerHTML = 'wind Speed:' + Math.floor(resultFromServer.wind.Speed) + 'meter/s';
    cityHeader.innerHTML = resultFromServer.name;
    humbidityElement.innerHTML = 'Humidity levels:' + resultFromServer.mian.humidity + '%';


    setPositionForweatherinfo();

}
function setPositionForweatherinfo()
{
    let weatherContainer = document.getElementById('weatherContainer');
    let weatherContainerHBeight = weatherContainer.clientHeight;
    let weatherContainerWidth = weatherContainer.clientWidth;

    weatherContainer.style.left = 'calc(50% - ${weatherContainerWidth/2}px)';
    weatherContainer.style.top = 'cal(50% - ${weathercontainerHeight/1.3}px)';
    weatherContainer.style.visibility = 'visible';

}
document.getElementById('searchBtn').addEventListener("click", () => {
    console.log(searchTerm)
    let searchTerm = document.getElementById('searchInput').Value;
    if(searchTerm)
     searchweather(searchTerm);
});
alert("Go!");
